# The Maze

This repository contains the skeleton code for the CS118 coursework. You can find more information about the coursework in The Guide to CS118.
